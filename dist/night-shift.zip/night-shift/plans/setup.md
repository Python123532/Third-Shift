# Setup plan

Run by 'TASK setup'. Re-running it lets the user change any answer. Use clickable multiple-choice questions where possible, at most 4 questions per card.

## 0. Say what Night Shift needs, before doing anything
First check that the Google Drive and Google Sheets connectors are available. If either is missing, name it, say to add it in Settings > Connectors, and stop until they have.

Then show this as a reply (not inside tool calls), and ask 'OK to go ahead?' with the answers 'Yes', 'No', and a question of their own:

> **What Night Shift uses, and why**
> | Access | What it does with it |
> |---|---|
> | Google Sheets | Reads and writes one sheet named 'Task Manager'. No other sheets. |
> | Google Drive | Creates that sheet and a 'Task Manager' folder, and saves finished work there. Later I'll ask (separately) whether I can read the titles of your 20 most recent files. |
> | Scheduled tasks | Runs at times you pick, while you're offline. Runs can act without asking you, within the limits below. |
> | Memory | Only if you say yes later: read what Claude already knows about you, to suggest a setup. |
>
> **Never, in any run:** send messages or emails, submit forms, buy anything, post publicly, or delete anything. Those get drafted and wait for you.
> Other tools (notes apps, repos, folders on your computer) are added only when you ask, and I'll say exactly what I'd read and write first.

On 'No', stop and say that nothing was created.

## 1. Find or create the sheet
Search the user's Drive for a spreadsheet named exactly 'Task Manager' that they own. Use an exact-title search (title equals 'Task Manager'), not a 'contains' search, which also matches files like 'Task Manager TEST' or 'Task Manager (old)'. If more than one exact match exists, ask which one.

- **If it exists:** use it. Don't change existing columns.
- **If it doesn't:** create it with the three core tabs and the exact columns from SKILL.md ('The sheet'):
  - dropdowns on Last Status, Priority, Effort, and Runs,
  - the header row frozen,
  - the first two columns (ID, Name) frozen.

## 2. Ask permission to learn from what the user already does
Ask this exact question as the question text of a choice card, with the answers 'Yes', 'No', and 'Tell me more':

> To tailor this to you, I can look at the titles of your 20 most recent Google Drive files and what I already remember about you. I'll only read titles, not the files themselves, and I won't save anything from them except a short summary of how you work (5 lines or fewer) that you can see and edit in your sheet. Is that OK?

- **Tell me more:** explain in two sentences what is read, what is saved, and where (the Profile row in __settings__). Then ask again.
- **No:** skip to step 4 and instead ask two questions:
  1. What kind of work do you mostly hand off? (research, writing, code, design, admin, other)
  2. What do you usually do with the results? (read once, edit and send, turn into slides or docs, other)

## 3. Learn and suggest (only if they said Yes)
1. Read the titles of the 20 most recent Drive files, plus whatever is already known about the user from memory. Read no file contents. Leave out the 'Task Manager' sheet, anything in the 'Task Manager' folder, and anything else this skill made (such as '(ID) (Name) spec' docs), and take the 20 most recent of what's left. Those show the skill, not the user.
2. Write a summary of how they work, 5 lines or fewer. Put the full summary inside the question text of a choice card ('Here's how you seem to work: (summary). Save it?'), with the answers 'Yes, save it', 'Change something', and 'Don't save it'. Don't show it outside the card. On 'Yes', save it to a Profile row in __settings__. On 'Change something', ask what to change, then show it again the same way.
3. Suggest **up to 3** ways the skill could fit what they do. Examples: a starting Standard for a tag they clearly use, an output format they produce often, a workflow such as turning a finished task's notes into a doc. Show them as a checklist card, with each suggestion's full wording in its answer text. Save only what they pick: Standards as Standards rows, anything else as a __settings__ row in their words.

## 4. Ask the schedule
Ask, then save each answer to __settings__ under these exact names:
1. **Timezone:** offer the one their device or memory suggests, plus 'other'.
2. **Offline Mode:** when are they usually not using Claude? Save as 'h:mm AM - h:mm PM'.
3. **Run Times:** suggest **1 run a day** (fewest tokens; most people need only this), with 2 or 3 as options for heavier queues. At what times inside Offline Mode? Suggest times 1 to 15 minutes before the hour (such as 2:58 AM), since on-the-hour runs can be delayed. Save comma-separated in time order. Every Run Time must be inside Offline Mode; if one isn't, say so and ask again.

## 5. Create the scheduled runs
Offer to create one scheduled task per Run Time. The first Run Time's task uses this prompt:

> Scheduled run of the user's Night Shift task queue (First run of Offline Mode). Nobody is watching. Load the night-shift skill and follow plans/scheduled-run.md exactly. The sheet is the Google Sheet 'Task Manager', ID (sheet ID). If the night-shift skill isn't available in this session, add one row to the Run Reviews tab saying so, then stop.

- Use it for the first Run Time, and turn on its push notification so the digest reaches the user.
- Every other Run Time gets this cheaper prompt, which skips loading the skill when there's nothing to do:

> Scheduled run of the user's Night Shift task queue (Regular run). Nobody is watching. The sheet is the Google Sheet 'Task Manager', ID (sheet ID). First, read only the Last Status and Runs columns of its Tasks tab. If no row has Runs 'Daily queue' and Last Status 'Not started' or 'In progress', reply 'Queue empty.' and stop. Otherwise load the night-shift skill and follow plans/scheduled-run.md exactly. If the skill isn't available, add one row to the Run Reviews tab saying so, then stop.

- Leave push notifications off for these.

## 6. Sample task (optional)
Offer a 2-minute sample so the user sees a finished, rated result right away: 'Want to try a tiny sample task now? It takes about 2 minutes.' On yes, create it with them in one card (suggest something small from their Profile, such as 'five key terms from (a class they take), one line each'; Effort S, two milestones), run it now as in plans/execute.md, then ask for their rating as in plans/review.md. On no, skip.

## 7. Close
Tell the user, in four lines or fewer:
- what was set up,
- that Standards and tool connections get set up the first time they come up,
- that anything can be changed by asking,
- and suggest 'TASK create' to add the first task.
